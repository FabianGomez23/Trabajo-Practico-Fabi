package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cliente.ClienteEmpresa;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CajaAhorro extends Cuenta {

    private double tasaInteres;

    public CajaAhorro(int numeroCuenta, ClienteEmpresa clienteAsociado, double tasaInteres) {
        super(numeroCuenta, clienteAsociado);
        this.tasaInteres = tasaInteres;
    }

    @Override
    public void depositarEfectivo(double monto) {

        if (monto > 0) {
            modificarSaldo(getSaldo() + monto);
        } else {
            System.out.println("No se pueden depositar montos negativos");
        }
    }

    @Override
    public void extraerEfectivo(double monto) {

        if (monto > 0 && monto <= getSaldo()) {
            modificarSaldo(getSaldo() - monto);
        } else {
            System.out.println("El monto es inválido o supera la cantidad del saldo.");
        }
    }

    public void cobrarInteres() {

        double intereses = getSaldo() * tasaInteres / 100;

        modificarSaldo(getSaldo() + intereses);
    }
}
