package ar.com.centro8.java.curso.cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Getter
@Setter
@ToString (callSuper = true)
/*
El parámetro callSuper le indica a Lombok queademás de incluir los campos de la clase actual, llame al método toString()
de la clase padre. Esto permite que la representación en cadena incluya también los campos heredados.
*/ 

public class ClienteEmpresa extends Cliente{  //acá hay una herencia

    private String nombreFantasia;
    private String cuit;

public ClienteEmpresa(int idCliente, String nombreFantasia, String cuit) {
        super(idCliente);
        this.nombreFantasia= nombreFantasia;
        this.cuit= cuit;
        
    }


}

    

