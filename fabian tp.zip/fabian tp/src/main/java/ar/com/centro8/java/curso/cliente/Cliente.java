package ar.com.centro8.java.curso.cliente;

import lombok.AllArgsConstructor;
import lombok.Getter;

import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor // constructor completo
public abstract class Cliente {
//no se pueden crear objetos de una clase abstracta
    
    private final int idCliente;

}