package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cliente.Cliente;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class CuentaCorriente extends Cuenta {

    private double montoGiroDescubierto;

    public CuentaCorriente(int numeroCuenta, Cliente clienteAsociado, double montoGiroDescubierto) {

        super(numeroCuenta, clienteAsociado);

        this.montoGiroDescubierto = montoGiroDescubierto;
    }

    @Override
    public void depositarEfectivo(double monto) {

        if (monto > 0) {
            modificarSaldo(getSaldo() + monto);
        } else {
            System.out.println("No se pueden depositar montos negativos");
        }
    }

    @Override
    public void extraerEfectivo(double monto) {

        if (monto > 0 && monto <= getSaldo() + montoGiroDescubierto) {
            modificarSaldo(getSaldo() - monto);
        } else {
            System.out.println("El monto es inválido o supera la cantidad del saldo.");
        }
    }

    public void depositarCheque(Cheque cheque) {

        if (cheque != null && cheque.getMonto() > 0) {
            modificarSaldo(getSaldo() + cheque.getMonto());
        } else {
            System.out.println("El monto del cheque debe ser mayor a 0");
        }
    }
}