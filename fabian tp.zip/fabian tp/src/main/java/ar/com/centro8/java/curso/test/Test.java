package ar.com.centro8.java.curso.test;

import java.time.LocalDate;

import ar.com.centro8.java.curso.cliente.ClienteEmpresa;
import ar.com.centro8.java.curso.cliente.ClienteIndividual;
import ar.com.centro8.java.curso.cuentas.CajaAhorro;
import ar.com.centro8.java.curso.cuentas.Cheque;
import ar.com.centro8.java.curso.cuentas.CuentaConvertibilidad;
import ar.com.centro8.java.curso.cuentas.CuentaCorriente;

public class Test {

    public static void main(String[] args) {

        // Crear cliente de empresa
        ClienteEmpresa cliente1 = new ClienteEmpresa(1, "Racing", "454343");

        // Crear caja de ahorro
        CajaAhorro caja = new CajaAhorro(1, cliente1, 5);

        
        // Probar depósito válido
        caja.depositarEfectivo(2000);
        System.out.println("Saldo después del depósito: " + caja.getSaldo());

        // Probar depósito negativo
        caja.depositarEfectivo(-500);

        // Probar una extracción 
        caja.extraerEfectivo(1000);
        System.out.println("Saldo después de extraer: " + caja.getSaldo());

        // Probar una extracción mayor al saldo
        caja.extraerEfectivo(50000);

        // Cobrar intereses del 5%
        caja.cobrarInteres();
        System.out.println("Saldo después de cobrar intereses: " + caja.getSaldo());





       // Crear cliente individual
        ClienteIndividual cliente2 = new ClienteIndividual(1, "Gustavo", "Costa", "23425");

        // Crear cuenta corriente        
        CuentaCorriente cuenta = new CuentaCorriente(1, cliente2, 5000);

        // Depositar efectivo
        cuenta.depositarEfectivo(2000);
        System.out.println("Saldo después del depósito: " + cuenta.getSaldo());

        // Intentar depositar un monto negativo
        cuenta.depositarEfectivo(-500);

        // Extraer dinero
        cuenta.extraerEfectivo(4000);
        System.out.println("Saldo después de extraer: " + cuenta.getSaldo());

        // Intentar superar el descubierto autorizado
        cuenta.extraerEfectivo(12000);

        // Crear un cheque válido
        Cheque cheque1 = new Cheque(3000, "Banco Nación", LocalDate.of(2026, 10, 23));

        // Depositar cheque
        cuenta.depositarCheque(cheque1);
        System.out.println("Saldo después del cheque: " + cuenta.getSaldo());

        // Crear un cheque negativo
        Cheque cheque2 = new Cheque(-1000, "Banco Nación", LocalDate.of(2026, 10, 23));

        // Intentar depositar el cheque negativo
        cuenta.depositarCheque(cheque2);
        System.out.println("Saldo final: " + cuenta.getSaldo());
   




        // Crear cliente individual
        ClienteEmpresa cuenta3 = new ClienteEmpresa(5, "Tesla", "5464565");

        // Crear cuenta de convertibilidad
        CuentaConvertibilidad cuentaConvertibilidad= new CuentaConvertibilidad(4, cuenta3, 100);

        // Depositar pesos
        cuentaConvertibilidad.depositarEfectivo(2000); 
        System.out.println("Saldo después del depósito en pesos: " + cuentaConvertibilidad.getSaldo());

        // Intentar depositar pesos negativos
        cuentaConvertibilidad.depositarEfectivo(-500);

        // Extraer pesos
        cuentaConvertibilidad.extraerEfectivo(3000);
        System.out.println("Saldo después de extraer pesos: " + cuentaConvertibilidad.getSaldo());

        // Intentar depositar dólares negativos
        cuentaConvertibilidad.depositarDolares(-10);

        // Depositar dólares
        cuentaConvertibilidad.depositarDolares(50);
        System.out.println("Saldo después del depósito en dólares: " + cuentaConvertibilidad.getSaldoDolares());

        // Debitar dólares
        cuentaConvertibilidad.debitarDolares(20);
        System.out.println("Saldo después de debitar dólares: " + cuentaConvertibilidad.getSaldoDolares());

        // Intentar debitar más dólares de los disponibles
        cuentaConvertibilidad.debitarDolares(500);

        // Convertir pesos a dólares
        // Tasa de ejemplo: 1000 pesos por dólar
        cuentaConvertibilidad.convertirPesosADolares(2000, 1000);
        System.out.println("Saldo en pesos después de convertir: " + cuentaConvertibilidad.getSaldo());
        System.out.println("Saldo en dólares después de convertir: " + cuentaConvertibilidad.getSaldoDolares());

        // Convertir dólares a pesos
        cuentaConvertibilidad.convertirDolaresAPesos(10, 1000);
        System.out.println("Saldo en pesos al final: " + cuentaConvertibilidad.getSaldo());
        System.out.println("Saldo en dólares al final: " + cuentaConvertibilidad.getSaldoDolares());
    
    
    }



      
    }

        
    




        
  
