package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cliente.Cliente;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public abstract class Cuenta {

    private final int numeroCuenta;

    private Cliente clienteAsociado;

    @Setter(AccessLevel.NONE)
    private double saldo;

    public Cuenta(int numeroCuenta, Cliente clienteAsociado) {
        this.numeroCuenta = numeroCuenta;
        this.clienteAsociado = clienteAsociado;
        
    }

    // protected permite que las clases hijas de Cuenta puedan usar ese método, pero evita que cualquiera desde afuera
    // pueda modificar el saldo directamente //
    
    protected void modificarSaldo(double nuevoSaldo) {
        this.saldo = nuevoSaldo;
    }
    // este metodo lo utilizo para poder modificar el saldo desde las clases hijas

    public abstract void depositarEfectivo(double monto);

    

    public abstract void extraerEfectivo(double monto);
}