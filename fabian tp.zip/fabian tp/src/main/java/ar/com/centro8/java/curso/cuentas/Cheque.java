package ar.com.centro8.java.curso.cuentas;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
@AllArgsConstructor
public class Cheque {

    private double monto;
    private String bancoEmisor;
    private LocalDate fechaPago;

    public void setMonto(Double monto) {

        if (monto == null) {
            System.out.println("El monto del cheque no puede ser nulo");
        } else if (monto < 0) {
            System.out.println("El monto del cheque no puede ser negativo");
        } else {
            this.monto = monto;
        }
    }
}