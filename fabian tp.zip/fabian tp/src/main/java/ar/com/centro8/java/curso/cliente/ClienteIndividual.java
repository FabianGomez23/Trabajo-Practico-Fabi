package ar.com.centro8.java.curso.cliente;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString (callSuper=true) 
/*
El parámetro callSuper le indica a Lombok queademás de incluir los campos de la clase actual, llame al método toString()
de la clase padre. Esto permite que la representación en cadena incluya también los campos heredados.
*/ 

public class ClienteIndividual extends Cliente {  //acá hay una herencia
    private String nombre;
    private String apellido;
    private String dni;



    public ClienteIndividual (int Idcliente, String nombre, String apellido, String dni) {
        super(Idcliente);
        this.nombre= nombre;
        this.apellido= apellido;
        this.dni= dni;
    }


}