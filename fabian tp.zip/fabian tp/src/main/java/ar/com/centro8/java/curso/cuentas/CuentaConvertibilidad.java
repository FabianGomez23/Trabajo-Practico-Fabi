package ar.com.centro8.java.curso.cuentas;

import ar.com.centro8.java.curso.cliente.ClienteEmpresa;
import lombok.Getter;
import lombok.ToString;

@Getter
@ToString(callSuper = true)
public class CuentaConvertibilidad extends CuentaCorriente {

    private double saldoDolares;

    public CuentaConvertibilidad(int numeroCuenta, ClienteEmpresa clienteAsociado, double montoGiroDescubierto) {

        super(numeroCuenta, clienteAsociado, montoGiroDescubierto);

    
    }

    public void depositarDolares(double monto) {

        if (monto > 0) {
            saldoDolares += monto;
        } else {
            System.out.println("No se pueden depositar montos negativos");
        }
    }

    public void debitarDolares(double monto) {

        if (monto > 0 && monto <= saldoDolares) {
            saldoDolares -= monto;
        } else {
            System.out.println("El monto es inválido o supera el saldo en dólares");
        }
    }

    public void convertirPesosADolares(double monto, double tasa) {

        if (monto > 0 && tasa > 0 && monto <= getSaldo()) {

            double dolares = monto / tasa;

            modificarSaldo(getSaldo() - monto);
            saldoDolares += dolares;

        } else {
            System.out.println("El monto o la tasa son inválidos, o no hay saldo suficiente");
        }
    }

    public void convertirDolaresAPesos(double monto, double tasa) {

        if (monto > 0 && tasa > 0 && monto <= saldoDolares) {

            double pesos = monto * tasa;

            saldoDolares -= monto;
            modificarSaldo(getSaldo() + pesos);

        } else { System.out.println("El monto o la tasa son inválidos, o no hay saldo suficiente");
        }
    }
}